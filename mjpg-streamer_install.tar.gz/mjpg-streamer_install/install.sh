#/bin/sh
opkg install kmod-i2c-core_3.10.49-1_ar71xx.ipk
opkg install kmod-video-core_3.10.49-1_ar71xx.ipk
opkg install kmod-input-core_3.10.49-1_ar71xx.ipk
opkg install kmod-video-videobuf2_3.10.49-1_ar71xx.ipk
opkg install kmod-video-uvc_3.10.49-1_ar71xx.ipk

opkg install libpthread_0.9.33.2-1_ar71xx.ipk
opkg install libjpeg_6b-1_ar71xx.ipk
opkg install librt_0.9.33.2-1_ar71xx.ipk
opkg install libv4l_1.2.1-2_ar71xx.ipk

opkg install mjpg-streamer_r182-1_ar71xx.ipk
