1. run install.sh
2. reboot
3. run startmjpg-streamer.sh
4. visit by http://192.168.1.1:8080
